// Content script: provides page-reading, field extraction, and action execution
(function () {
  if (window.__ai_voice_content_installed) return console.log('AI Voice content script already installed');
  window.__ai_voice_content_installed = true;
  console.log('AI Voice content script loaded');

  const safeSpeak = (text, opts = {}) => {
    if (!text) return;
    try {
      const ut = new SpeechSynthesisUtterance(String(text));
      ut.rate = opts.rate || 1.0;
      window.speechSynthesis.speak(ut);
    } catch (e) { /* ignore TTS errors */ }
  };

  const getSelectionText = () => {
    try {
      const s = window.getSelection();
      if (s && s.toString().trim()) return s.toString().trim();
      const active = document.activeElement;
      if (active && (active.tagName === 'TEXTAREA' || (active.tagName === 'INPUT' && active.type === 'text'))) return active.value || '';
    } catch (e) {}
    return '';
  };

  const getPageArticleText = () => {
    try {
      const el = document.querySelector('article') || document.querySelector('main');
      if (el) return el.innerText.trim().slice(0, 20000);
      const paras = Array.from(document.querySelectorAll('p'));
      const visible = paras.filter(p => p.offsetParent !== null);
      return visible.map(p => p.innerText.trim()).filter(Boolean).slice(0, 200).join('\n\n');
    } catch (e) { return ''; }
  };

  const extractFormFields = () => {
    try {
      const els = Array.from(document.querySelectorAll('input, textarea, select'));
      const visible = els.filter(e => e.offsetParent !== null && e.type !== 'hidden');
      return visible.slice(0, 200).map((el, i) => {
        const tag = el.tagName.toLowerCase();
        const type = el.type || tag;
        const id = el.id || null;
        const name = el.name || null;
        const placeholder = el.placeholder || el.getAttribute('aria-label') || '';
        let label = '';
        if (id) {
          const lab = document.querySelector(`label[for="${id}"]`);
          if (lab) label = lab.innerText.trim();
        }
        if (!label) {
          const clos = el.closest('label');
          if (clos) label = clos.innerText.trim();
        }
        let selector = '';
        if (id) selector = `#${id}`;
        else if (name) selector = `${tag}[name="${name}"]`;
        else if (placeholder) selector = `${tag}[placeholder]`;
        else selector = `${tag}:nth-of-type(${i + 1})`;
        return { label: label || '', selector, name, id, type, placeholder };
      });
    } catch (e) { return []; }
  };

  // helper: attempt robust click on element (top-level so we can reuse it)
  const doClick = async (el) => {
    try {
      if (!el) return { ok: false, error: 'no-element' };
      // ensure element is in view and allow layout to settle
      try { el.scrollIntoView({ block: 'center', inline: 'center', behavior: 'auto' }); } catch (e) {}
      await new Promise(r => setTimeout(r, 80));
      // temporary visual hint
      try { el.style.outline = '3px solid #06f'; setTimeout(() => { try { el.style.outline = ''; } catch (e) {} }, 2200); } catch (e) {}

      const rect = el.getBoundingClientRect();
      if (!rect || rect.width <= 0 || rect.height <= 0) {
        // not visible clickable area; try programmatic click
        try { el.click(); } catch (e) {}
        return { ok: true, fallback: 'zero-area-click' };
      }

      const cx = Math.round(rect.left + rect.width / 2);
      const cy = Math.round(rect.top + rect.height / 2);
      const samplePoints = [
        [cx, cy],
        [Math.round(rect.left + Math.min(8, rect.width / 4)), cy],
        [Math.round(rect.right - Math.min(8, rect.width / 4)), cy],
        [cx, Math.round(rect.top + Math.min(8, rect.height / 4))],
        [cx, Math.round(rect.bottom - Math.min(8, rect.height / 4))]
      ];

      let chosen = null;
      let topEl = null;
      for (const [x, y] of samplePoints) {
        const vx = Math.max(0, Math.min(window.innerWidth - 1, x));
        const vy = Math.max(0, Math.min(window.innerHeight - 1, y));
        let found = null;
        try { found = document.elementFromPoint(vx, vy); } catch (e) { found = null; }
        if (!found) continue;
        // accept if element itself or a direct descendant/ancestor is topmost
        if (found === el || el.contains(found) || found.contains(el)) {
          chosen = [vx, vy]; topEl = found; break;
        }
      }

      // if no matching top element found, try a retry after a short nudge (in case of transient overlays)
      if (!chosen) {
        try { window.scrollBy(0, -10); } catch (e) {}
        await new Promise(r => setTimeout(r, 50));
        const vx = Math.max(0, Math.min(window.innerWidth - 1, cx));
        const vy = Math.max(0, Math.min(window.innerHeight - 1, cy));
        try { topEl = document.elementFromPoint(vx, vy); } catch (e) { topEl = null; }
        console.warn('AI Voice click: elementFromPoint mismatch', { resolved: el, rect, topEl });
      }

      const [px, py] = chosen || [Math.max(0, Math.min(window.innerWidth - 1, cx)), Math.max(0, Math.min(window.innerHeight - 1, cy))];
      const opts = { bubbles: true, cancelable: true, view: window, clientX: px, clientY: py };

      // determine dispatch target
      let dispatchTarget = el;
      try {
        if (topEl && (topEl === el || el.contains(topEl) || topEl.contains(el))) dispatchTarget = topEl;
      } catch (e) {}

      // if dispatchTarget (or its computed style) blocks pointer events, fallback to el.click()
      try {
        const cs = window.getComputedStyle(dispatchTarget);
        if (cs && cs.pointerEvents === 'none') {
          try { el.click(); } catch (e) {}
          return { ok: true, fallback: 'pointer-events-none' };
        }
      } catch (e) {}

      // dispatch synthetic pointer/mouse events, then fallback to programmatic click
      try {
        const pointerDown = new PointerEvent('pointerdown', Object.assign({ pointerId: 1, isPrimary: true }, opts));
        const mouseDown = new MouseEvent('mousedown', opts);
        const mouseUp = new MouseEvent('mouseup', opts);
        const clickEvt = new MouseEvent('click', opts);
        try { dispatchTarget.dispatchEvent(pointerDown); } catch (e) {}
        await new Promise(r => setTimeout(r, 25));
        try { dispatchTarget.dispatchEvent(mouseDown); } catch (e) {}
        await new Promise(r => setTimeout(r, 20));
        try { dispatchTarget.dispatchEvent(mouseUp); } catch (e) {}
        await new Promise(r => setTimeout(r, 15));
        try { dispatchTarget.dispatchEvent(clickEvt); } catch (e) {}
      } catch (e) {
        console.warn('AI Voice click dispatch error', e);
      }

      // ensure handlers that only observe programmatic clicks still run
      try { el.focus && el.focus(); } catch (e) {}
      try { el.click(); } catch (e) {}

      return { ok: true, method: 'dispatched', usedTarget: (dispatchTarget === el ? 'resolved' : 'topEl') };
    } catch (e) { return { ok: false, error: String(e) }; }
  };

  // (click-tracking is handled per-run inside PROPOSE_ACTION)

  // wait for a selector to appear in the document or same-origin iframes
  const waitForElement = async (selector, timeout = 3000, interval = 150) => {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      try {
        const found = findInDocument(document, selector) || findInIframes(selector);
        if (found && found.el && found.el.offsetParent !== null) return found;
      } catch (e) {}
      await new Promise(r => setTimeout(r, interval));
    }
    return null;
  };

  // helper: try selector directly, deep (shadow) and same-origin iframes
  const findInDocument = (rootDoc, selector) => {
    try {
      if (!selector) return null;
      let el = null;
      try { el = rootDoc.querySelector(selector); } catch (e) { el = null; }
      if (el) return { el, context: rootDoc };
      const all = Array.from(rootDoc.querySelectorAll('*'));
      for (const node of all) {
        if (node.shadowRoot) {
          try {
            const s = node.shadowRoot.querySelector(selector);
            if (s) return { el: s, context: node.shadowRoot };
          } catch (e) {}
        }
      }
      return null;
    } catch (e) { return null; }
  };

  // helper: search same-origin iframes
  const findInIframes = (selector) => {
    const iframes = Array.from(document.querySelectorAll('iframe'));
    for (const fr of iframes) {
      try {
        const doc = fr.contentDocument;
        if (!doc) continue;
        const found = findInDocument(doc, selector);
        if (found) return found;
      } catch (e) { /* cross-origin or inaccessible */ }
    }
    return null;
  };

  const isVisibleElement = (el) => {
    try {
      if (!el) return false;
      if (el.offsetParent === null) return false;
      const style = window.getComputedStyle(el);
      if (style && (style.visibility === 'hidden' || style.display === 'none' || parseFloat(style.opacity || '1') === 0)) return false;
      return true;
    } catch (e) { return false; }
  };

  const centerOf = (el) => {
    try {
      const r = el.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    } catch (e) { return { x: 0, y: 0 }; }
  };

  // resolve element for an action using selectors, text heuristics, and proximity to a reference element
  const resolveActionElement = async (action, referenceEl = null, timeout = 2500) => {
    try {
      // 1) selector-based resolution (may match multiple)
      if (action.selector) {
        // wait briefly for dynamic elements
        const waited = await waitForElement(action.selector, timeout);
        let candidates = [];
        try { candidates = Array.from(document.querySelectorAll(action.selector)); } catch (e) { candidates = []; }
        candidates = candidates.filter(e => isVisibleElement(e) && !e.disabled);
        if (candidates.length === 1) return { el: candidates[0], method: 'selector-single' };
        if (candidates.length > 1) {
            // score candidates by text match, attribute hints, and proximity
            const target = ((action.text || action.label || action.value) || '').trim().toLowerCase();
            const keywords = (target || action.selector || action.type || '').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
            const scoreFor = (c) => {
              let score = 0;
              const text = ((c.innerText || c.value || c.getAttribute('aria-label') || c.getAttribute('title') || '') + '').trim().toLowerCase();
              if (text && target) {
                if (text === target) score += 200;
                else if (text.startsWith(target) || target.startsWith(text)) score += 150;
                else if (text.split(' ').some(w=> target.includes(w))) score += 90;
                else if (text.includes(target) || target.includes(text)) score += 70;
              }
              // attribute-based hints
              try {
                const attrs = ((c.id || '') + ' ' + (c.name || '') + ' ' + (c.className || '')).toLowerCase();
                for (const k of keywords) if (k && attrs.includes(k)) score += 40;
              } catch (e) {}
              // proximity to reference element
              if (referenceEl) {
                try { const a = centerOf(c), b = centerOf(referenceEl); const d = Math.hypot(a.x-b.x, a.y-b.y); score += Math.max(0, 120 - d/4); } catch (e) {}
              }
              // prefer actual <button> and clickable semantics
              try { const tag = (c.tagName || '').toLowerCase(); if (tag === 'button') score += 30; if (c.getAttribute && c.getAttribute('role') === 'button') score += 20; } catch (e) {}
              return score;
            };
            const ranked = candidates.map(c => ({ c, s: scoreFor(c) }));
            ranked.sort((a,b) => b.s - a.s);
            if (ranked.length && ranked[0].s > 40) return { el: ranked[0].c, method: 'selector-scored', score: ranked[0].s };
            // if no strong score, pick nearest to reference if available
            if (referenceEl) {
              const pref = candidates.map(c => ({ c, d: (function(){ const a = centerOf(c), b = centerOf(referenceEl); return Math.hypot(a.x-b.x, a.y-b.y); })() })).sort((a,b) => a.d - b.d);
              return { el: pref[0].c, method: 'selector-nearest' };
            }
            // otherwise fall through to broader heuristics below
        }
        // if waited and found via waitForElement
        if (waited && waited.el && isVisibleElement(waited.el) && !waited.el.disabled) return { el: waited.el, method: 'selector-waited' };
      }

      // 2) text-based resolution, prefer near referenceEl
      if (action.text || action.label || action.value || action.query) {
        const byText = findByText(action.text || action.label || action.value || action.query || '');
        if (byText && byText.el && isVisibleElement(byText.el) && !byText.el.disabled) {
          if (!referenceEl) return { el: byText.el, method: 'text-' + (byText.method || 'match') };
          // if reference provided, ensure proximity
          try {
            const a = centerOf(byText.el), b = centerOf(referenceEl);
            const dist = Math.hypot(a.x-b.x, a.y-b.y);
            if (dist < 600) return { el: byText.el, method: 'text-near-' + (byText.method || 'match') };
          } catch (e) { return { el: byText.el, method: 'text-match' }; }
        }
      }

      // 3) fallback: pick the nearest visible clickable element to referenceEl
      if (referenceEl) {
        const clickable = Array.from(document.querySelectorAll('button, a[href], input[type=button], input[type=submit], [role="button"]')).filter(e => isVisibleElement(e) && !e.disabled);
        if (clickable.length) {
          const pref = clickable.map(c => ({ c, d: (function(){ const a = centerOf(c), b = centerOf(referenceEl); return Math.hypot(a.x-b.x, a.y-b.y); })() })).sort((a,b) => a.d - b.d);
          return { el: pref[0].c, method: 'fallback-nearest-clickable' };
        }
      }

      // final fallback: first visible clickable in document
      const generic = Array.from(document.querySelectorAll('button, a[href], input[type=button], input[type=submit]')).find(e => isVisibleElement(e) && !e.disabled);
      if (generic) return { el: generic, method: 'fallback-generic' };
      return null;
    } catch (e) { console.warn('resolveActionElement error', e); return null; }
  };

  // detect a primary input or output area on the page to anchor the first action
  const detectPrimaryInput = () => {
    try {
      // prefer currently focused editable element
      const active = document.activeElement;
      if (active && (active.tagName === 'TEXTAREA' || (active.tagName === 'INPUT' && /text|search/.test(active.type)) || active.isContentEditable)) return active;
      // look for visible textarea or large input with user content
      const candidates = Array.from(document.querySelectorAll('textarea, input[type=text], input[type=search], [contenteditable]')).filter(e => isVisibleElement(e));
      let best = null; let bestScore = -1;
      for (const c of candidates) {
        try {
          const value = (c.value || c.innerText || '').trim();
          const rect = c.getBoundingClientRect();
          const area = rect.width * rect.height;
          let score = 0;
          if (value && value.length > 20) score += 200 + Math.min(500, value.length);
          score += Math.min(300, area / 100);
          if (score > bestScore) { best = c; bestScore = score; }
        } catch (e) {}
      }
      if (best) return best;
      // fallback: a large visible element (article/main) near top
      const mains = Array.from(document.querySelectorAll('main, article')).filter(e => isVisibleElement(e));
      if (mains && mains.length) return mains[0];
      return null;
    } catch (e) { return null; }
  };

  // helper: find by visible text/label when selector missing or fails
  const findByText = (text) => {
    if (!text) return null;
    const norm = (s) => (s || '').trim().replace(/\s+/g, ' ').toLowerCase();
    const target = norm(text);
    // gather likely button-like candidates first
    const candidates = Array.from(document.querySelectorAll('button, a, input[type=button], input[type=submit], [role="button"]'))
      .filter(e => e.offsetParent !== null);

    const textFor = (c) => {
      try { return norm(c.innerText || c.value || c.getAttribute('aria-label') || c.getAttribute('title') || ''); } catch (e) { return ''; }
    };

    // 1) exact match
    for (const c of candidates) {
      const t = textFor(c);
      if (t && t === target) return { el: c, context: document, method: 'exact' };
    }
    // 2) startsWith
    for (const c of candidates) {
      const t = textFor(c);
      if (t && (t.startsWith(target) || target.startsWith(t))) return { el: c, context: document, method: 'startsWith' };
    }
    // 3) word-boundary contains
    const wordRe = new RegExp('\\b' + target.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&') + '\\b', 'i');
    for (const c of candidates) {
      const t = textFor(c);
      if (t && wordRe.test(t)) return { el: c, context: document, method: 'wordMatch' };
    }

    // 4) fallback to broader visible elements but prefer nearer matches
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT, null, false);
    let n;
    while ((n = walker.nextNode())) {
      try {
        if (n.offsetParent === null) continue;
        const t = norm(n.innerText || '');
        if (!t) continue;
        if (t === target || t.includes(target) || target.includes(t)) return { el: n, context: document, method: 'walker' };
      } catch (e) {}
    }
    return null;
  };

  const performAction = async (action) => {
    try {
      if (!action || !action.type) return { ok: false, error: 'no-action' };
      // navigate
      if (action.type === 'navigate' && action.url) { window.location.href = action.url; return { ok: true }; }

      // If caller provided an explicit element reference, use it
      const explicitEl = action._el || null;

      if (action.type === 'click') {
          if (explicitEl) return await doClick(explicitEl);
        const selector = action.selector || action.selectorRaw || null;
        console.log('AI Voice performAction click requested:', action);
        if (selector) {
          console.log('AI Voice trying selector:', selector);
          let found = findInDocument(document, selector) || findInIframes(selector);
          if (found && found.el) return await doClick(found.el);
          console.log('AI Voice selector not found in main doc or iframes, will try fallback text/heuristics');
        }
        const byText = findByText(action.text || action.label || action.value || action.query || '');
        if (byText && byText.el) return await doClick(byText.el);
        const generic = Array.from(document.querySelectorAll('button, a[href], input[type=button], input[type=submit]')).find(e => e.offsetParent !== null);
        if (generic) {
          console.log('AI Voice falling back to generic clickable element');
          return await doClick(generic);
        }
        return { ok: false, error: 'selector_not_found_or_no_clickable_element' };
      }

      if (action.type === 'fill') {
        const selector = action.selector || action.selectorRaw || null;
        if (!selector && !explicitEl) return { ok: false, error: 'no-selector-for-fill' };
        let found = null;
        if (explicitEl) found = { el: explicitEl };
        else found = findInDocument(document, selector) || findInIframes(selector);
        if (!found || !found.el) return { ok: false, error: 'selector not found' };
        const el = found.el;
        try {
          el.focus();
          el.value = action.value || '';
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return { ok: true };
        } catch (e) { return { ok: false, error: String(e) }; }
      }

      return { ok: false, error: 'unknown action type' };
    } catch (e) { return { ok: false, error: String(e) }; }
  };

  // try to open a long-lived port
  let port = null;
  try { port = chrome.runtime.connect({ name: 'ai-voice-port' }); try { port.postMessage({ type: 'REGISTER' }); } catch(e){} } catch (e) { port = null; }

  const handle = async (message) => {
    if (!message || !message.type) return { ok: false, error: 'no-type' };
    if (message.type === 'AI_VOICE_PING' || message.type === 'PING') return { ok: true, pong: true };
    if (message.type === 'READ_SELECTION') { const txt = getSelectionText() || getPageArticleText(); safeSpeak(txt, { rate: 1.0 }); return { ok: true, text: txt }; }
    if (message.type === 'READ_PAGE') { const txt = getPageArticleText(); safeSpeak(txt, { rate: 1.0 }); return { ok: true, text: txt }; }
    if (message.type === 'GET_PAGE_TEXT') { return { ok: true, text: { text: getPageArticleText(), fields: extractFormFields() } }; }
    if (message.type === 'PROPOSE_ACTION') {
      const proposal = message.payload || {};
      // normalize to array of actions
      let actions = [];
      if (Array.isArray(proposal)) actions = proposal;
      else if (Array.isArray(proposal.actions)) actions = proposal.actions;
      else if (proposal.action) actions = [proposal.action];
      else if (proposal.actions && typeof proposal.actions === 'object') actions = Array.from(proposal.actions || []);
      const confirmMsg = proposal && proposal.message ? proposal.message : (actions.length > 1 ? `Assistant suggests ${actions.length} actions. Allow all?` : 'Assistant suggests an action. Allow?');
      const auto = !!proposal.force || !!proposal.auto || false;
      if (!auto) {
        const proceed = window.confirm(confirmMsg + '\n\n(Click OK to allow the assistant to perform the action(s) on this page.)');
        if (!proceed) return { ok: false, cancelled: true };
      }
      const results = [];
      const clickedThisRun = new WeakSet();
      for (let i = 0; i < actions.length; i++) {
        try {
          const act = actions[i] || {};
          // resolve element for this action just before executing, prefer previous action's element as reference
          const prevEl = (i > 0 && actions[i-1] && actions[i-1]._el) ? actions[i-1]._el : null;
          const resolved = await resolveActionElement(act, prevEl, 3000);
          if (resolved && resolved.el) {
            if (clickedThisRun.has(resolved.el)) {
              console.log(`AI Voice skipping already-clicked element for action[${i}]`, act);
            } else {
              act._el = resolved.el;
              console.log(`AI Voice resolved action[${i}] using method`, resolved.method);
            }
          } else {
            console.log(`AI Voice could not resolve element for action[${i}]`, act);
          }

          // perform each action sequentially
          const r = await performAction(act);
          // record clicked element if successful
          try {
            if (r && r.ok && act._el) clickedThisRun.add(act._el);
          } catch (e) {}
          results.push(r || { ok: false, error: 'no-result' });
        } catch (e) {
          results.push({ ok: false, error: String(e) });
        }
        // pause between actions to allow page handlers to settle
        await new Promise(res => setTimeout(res, 600));
      }
      return { ok: true, results };
    }
    if (message.type === 'PERFORM_ACTION') return await performAction(message.payload || {});
    if (message.type === 'STOP_SPEECH') { try { window.speechSynthesis.cancel(); return { ok: true }; } catch (e) { return { ok: false, error: String(e) }; } }
    if (message.type === 'START_RECOGNITION') { injectRecognizerIfNeeded(); window.postMessage({ source: 'ai-voice-extension-pagecontrol', cmd: 'start' }, '*'); return { ok: true }; }
    if (message.type === 'STOP_RECOGNITION') { window.postMessage({ source: 'ai-voice-extension-pagecontrol', cmd: 'stop' }, '*'); return { ok: true }; }
    return { ok: false, error: 'unknown-type' };
  };

  // runtime messages
  try {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      handle(message).then(sendResponse).catch(e => sendResponse({ ok: false, error: String(e) }));
      return true;
    });
  } catch (e) { console.warn('runtime.onMessage not available', e); }

  // expose a method to enumerate actionable items on the page
  try {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || !message.type) return;
      if (message.type === 'GET_ACTIONABLE_ITEMS') {
        try {
          const items = [];
          const collect = (el) => {
            try {
              if (!el) return;
              const tag = (el.tagName || '').toLowerCase();
              const rect = (() => { try { const r = el.getBoundingClientRect(); return { x: Math.round(r.left), y: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height) }; } catch (e) { return null; } })();
              const text = (el.innerText || el.value || el.getAttribute && (el.getAttribute('aria-label') || el.getAttribute('title')) || '').toString().trim();
              let selector = '';
              try {
                if (el.id) selector = `#${el.id}`;
                else if (el.name) selector = `${tag}[name="${el.name}"]`;
                else if (el.getAttribute && el.getAttribute('data-test')) selector = `${tag}[data-test="${el.getAttribute('data-test')}"]`;
                else if (el.className) selector = `${tag}.${(el.className || '').toString().split(/\s+/).filter(Boolean).slice(0,2).join('.')}`;
                else selector = tag;
              } catch (e) { selector = tag; }
              items.push({ tag, selector, text, rect, visible: el.offsetParent !== null, disabled: el.disabled || false, role: el.getAttribute && el.getAttribute('role') || '' });
            } catch (e) {}
          };
          const actionable = Array.from(document.querySelectorAll('button, a[href], input[type=button], input[type=submit], [role="button"], input[type=text], textarea, select'));
          for (const a of actionable) collect(a);
          // include forms as documents
          const forms = Array.from(document.querySelectorAll('form'));
          for (const f of forms) {
            try { items.push({ tag: 'form', selector: (f.id ? `#${f.id}` : ''), text: (f.getAttribute && f.getAttribute('name')) || '', rect: null, visible: f.offsetParent !== null }); } catch (e) {}
          }
          sendResponse({ ok: true, items });
        } catch (e) { sendResponse({ ok: false, error: String(e) }); }
        return true;
      }
    });
  } catch (e) { /* ignore */ }

  // handle request to open/close a persistent in-page UI panel
  try {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!message || !message.type) return;
      if (message.type === 'OPEN_INPAGE_UI') {
        try { openInpagePanel(); sendResponse({ ok: true }); } catch (e) { sendResponse({ ok: false, error: String(e) }); }
        return true;
      }
      if (message.type === 'CLOSE_INPAGE_UI') {
        try { if (window.__ai_voice_inpage_panel) { window.__ai_voice_inpage_panel.remove(); window.__ai_voice_inpage_panel = null; } sendResponse({ ok: true }); } catch (e) { sendResponse({ ok: false, error: String(e) }); }
        return true;
      }
      // otherwise fall through to generic handlers
    });
  } catch (e) { /* ignore */ }

  // port messages
  if (port) {
    try {
      port.onMessage.addListener(async (msg) => {
        if (!msg) return;
        const id = msg.id;
        const resp = await handle(msg).catch(e => ({ ok: false, error: String(e) }));
        try { port.postMessage({ id, resp }); } catch (e) {}
      });
    } catch (e) { /* ignore */ }
  }

  // page -> extension forwarding for injected recognizer
  window.addEventListener('message', (event) => {
    if (!event || !event.data) return;
    const msg = event.data;
    if (msg && msg.source === 'ai-voice-page-speech') {
      if (msg.transcript) chrome.runtime.sendMessage({ type: 'RECOGNITION_RESULT', transcript: msg.transcript }, () => {});
      if (msg.event === 'end') chrome.runtime.sendMessage({ type: 'RECOGNITION_END' }, () => {});
    }
  });

  // recognizer injection (page context)
  const injectRecognizerIfNeeded = () => {
    if (window.__ai_voice_injected) return;
    try {
      const script = document.createElement('script');
      script.textContent = `(() => {
        if (window.__ai_voice_recognizer) return;
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) return;
        const rec = new SpeechRecognition(); rec.lang = 'en-US'; rec.interimResults = false; rec.continuous = true;
        rec.addEventListener('result', (ev) => { const t = ev.results[ev.results.length-1][0].transcript.trim(); window.postMessage({ source: 'ai-voice-page-speech', transcript: t }, '*'); });
        rec.addEventListener('end', () => { window.postMessage({ source: 'ai-voice-page-speech', event: 'end' }, '*'); });
        window.__ai_voice_recognizer = { start: () => { try { rec.start(); } catch(e){} }, stop: () => { try { rec.stop(); } catch(e){} } };
        window.addEventListener('message', (ev) => { const m = ev.data || {}; if (m && m.source === 'ai-voice-extension-pagecontrol') { if (m.cmd === 'start') try { window.__ai_voice_recognizer.start(); } catch(e) {} if (m.cmd === 'stop') try { window.__ai_voice_recognizer.stop(); } catch(e) {} } });
      })();`;
      document.documentElement.appendChild(script);
      script.remove();
      window.__ai_voice_injected = true;
    } catch (e) { /* ignore */ }
  };

  // create a floating in-page panel containing extension UI (iframe to popup.html)
  function openInpagePanel() {
    if (window.__ai_voice_inpage_panel) {
      // bring to front
      const p = window.__ai_voice_inpage_panel;
      p.style.display = 'block';
      p.style.zIndex = 2147483647;
      return;
    }
    const panel = document.createElement('div');
    panel.style.position = 'fixed';
    panel.style.right = '12px';
    panel.style.bottom = '12px';
    panel.style.width = '380px';
    panel.style.height = '620px';
    panel.style.zIndex = 2147483647;
    panel.style.boxShadow = '0 4px 16px rgba(0,0,0,0.25)';
    panel.style.borderRadius = '6px';
    panel.style.overflow = 'hidden';
    panel.style.background = '#fff';

    const header = document.createElement('div');
    header.style.background = '#2f6';
    header.style.padding = '6px 8px';
    header.style.fontSize = '13px';
    header.style.display = 'flex';
    header.style.justifyContent = 'space-between';
    header.style.alignItems = 'center';
    header.textContent = 'AI Voice Assistant';
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.marginLeft = '8px';
    closeBtn.style.cursor = 'pointer';
    closeBtn.addEventListener('click', () => { panel.remove(); window.__ai_voice_inpage_panel = null; });
    header.appendChild(closeBtn);

    const iframe = document.createElement('iframe');
    iframe.src = chrome.runtime.getURL('popup.html') + '?inpage=1';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = '0';

    panel.appendChild(header);
    panel.appendChild(iframe);
    // adjust header and iframe sizes
    header.style.height = '34px';
    iframe.style.height = 'calc(100% - 34px)';

    document.documentElement.appendChild(panel);
    window.__ai_voice_inpage_panel = panel;
  }

})();
