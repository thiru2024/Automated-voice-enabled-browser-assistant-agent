chrome.runtime.onInstalled.addListener(() => {
  console.log('AI Voice extension installed');
});

// track connected content-script ports by tabId
const __ai_voice_ports = new Map();
// track actions in progress per tabId
const __ai_voice_inprogress = new Map();
// timers to clear stale in-progress state
const __ai_voice_inprogress_timers = new Map();
chrome.runtime.onConnect.addListener((port) => {
  if (!port || port.name !== 'ai-voice-port') return;
  const tab = port.sender && port.sender.tab;
  if (!tab) return;
  __ai_voice_ports.set(tab.id, port);
  console.log('Port connected from tab', tab.id, tab.url);
  port.onDisconnect.addListener(() => {
    __ai_voice_ports.delete(tab.id);
    console.log('Port disconnected for tab', tab.id);
  });
});

// Allow opening a persistent extension window so the UI doesn't auto-close.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || (msg.type !== 'OPEN_PERSISTENT_WINDOW' && msg.type !== 'OPEN_INPAGE_UI' && msg.type !== 'START_ACTION' && msg.type !== 'END_ACTION' && msg.type !== 'GET_ACTION_STATUS')) return;
  // If caller requested in-page UI, send to active tab's content script
  if (msg.type === 'OPEN_INPAGE_UI') {
    // find active tab and try to forward the request
    chrome.windows.getLastFocused({ populate: true }, (win) => {
      if (chrome.runtime.lastError || !win) {
        chrome.windows.getAll({ populate: true }, (wins) => {
          const chosen = (wins || []).find(w => w.focused && w.type === 'normal') || (wins && wins[0]);
          const tab = chosen && chosen.tabs && chosen.tabs.find(t => t.active) || (chosen && chosen.tabs && chosen.tabs[0]);
          if (!tab) { sendResponse({ ok: false, error: 'no-active-tab' }); return; }
          forwardOpenInpage(tab.id, sendResponse);
        });
        return;
      }
      const tab = (win.tabs || []).find(t => t.active) || (win.tabs && win.tabs[0]);
      if (!tab) { sendResponse({ ok: false, error: 'no-active-tab' }); return; }
      forwardOpenInpage(tab.id, sendResponse);
    });
    return true;
  }
  // background action state API
  if (msg.type === 'START_ACTION') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs && tabs[0] && tabs[0].id;
      if (tabId) {
        __ai_voice_inprogress.set(tabId, true);
        chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId, inProgress: true });
        sendResponse({ ok: true });
      } else sendResponse({ ok: false });
    });
    return true;
  }
  if (msg.type === 'END_ACTION') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs && tabs[0] && tabs[0].id;
      if (tabId) {
        __ai_voice_inprogress.delete(tabId);
        chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId, inProgress: false });
        sendResponse({ ok: true });
      } else sendResponse({ ok: false });
    });
    return true;
  }
  if (msg.type === 'GET_ACTION_STATUS') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs && tabs[0] && tabs[0].id;
      const inProg = tabId ? !!__ai_voice_inprogress.get(tabId) : false;
      sendResponse({ ok: true, inProgress: inProg });
    });
    return true;
  }
  // fallback: OPEN_PERSISTENT_WINDOW - open or focus a tab with popup.html
  const popupUrl = chrome.runtime.getURL('popup.html');
  chrome.tabs.query({ url: popupUrl }, (tabs) => {
    if (chrome.runtime.lastError) {
      chrome.tabs.create({ url: popupUrl, active: true }, (t) => sendResponse({ ok: !!t, tabId: t && t.id }));
      return;
    }
    if (tabs && tabs.length) {
      const t = tabs[0];
      chrome.windows.update(t.windowId, { focused: true }, () => {
        chrome.tabs.update(t.id, { active: true }, (ut) => sendResponse({ ok: true, tabId: ut && ut.id }));
      });
      return;
    }
    chrome.tabs.create({ url: popupUrl, active: true }, (t) => sendResponse({ ok: !!t, tabId: t && t.id }));
  });
  return true;

  function forwardOpenInpage(tabId, sendResponse) {
    // send a message to content script; if no receiver, inject content script then retry
    chrome.tabs.sendMessage(tabId, { type: 'OPEN_INPAGE_UI' }, (resp) => {
      if (!chrome.runtime.lastError) { sendResponse({ ok: true, forwarded: !!resp }); return; }
      // inject then try again
      chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }, () => {
        if (chrome.runtime.lastError) { sendResponse({ ok: false, error: chrome.runtime.lastError.message }); return; }
        setTimeout(() => {
          chrome.tabs.sendMessage(tabId, { type: 'OPEN_INPAGE_UI' }, (r2) => { if (chrome.runtime.lastError) sendResponse({ ok: false, error: chrome.runtime.lastError.message }); else sendResponse({ ok: true, forwarded: !!r2 }); });
        }, 80);
      });
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('Background received message:', message);
  // Forward messages to the active tab's content script when appropriate
  if (!message || !message.type) return sendResponse({ok: false, error: 'no-type'});
  // If caller provided an explicit tabId (e.g., popup targeting the page), forward to that tab
  if (message.tabId) {
    const targetTabId = message.tabId;
    const forwardTypesLocal = ['READ_SELECTION','READ_PAGE','GET_PAGE_TEXT','PROPOSE_ACTION','PERFORM_ACTION','START_RECOGNITION','STOP_RECOGNITION','STOP_SPEECH'];
    if (!forwardTypesLocal.includes(message.type)) return sendResponse({ ok: false, error: 'unsupported' });
    // validate tab exists and url
    chrome.tabs.get(targetTabId, (tab) => {
      if (chrome.runtime.lastError || !tab) return sendResponse({ ok: false, error: 'invalid_tab' });
      const url = tab.url || '';
      // mark action in-progress for the target tab and set a safety timer
      try {
        __ai_voice_inprogress.set(tab.id, true);
        chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: true });
        const tId = setTimeout(() => {
          console.warn('Clearing stale in-progress for tab', tab.id);
          __ai_voice_inprogress.delete(tab.id);
          __ai_voice_inprogress_timers.delete(tab.id);
          chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: false });
        }, 15000);
        __ai_voice_inprogress_timers.set(tab.id, tId);
      } catch (e) {}
      try { const proto = new URL(url).protocol; if (proto !== 'http:' && proto !== 'https:') return sendResponse({ ok: false, error: 'unsupported_tab_url', url }); } catch (e) { return sendResponse({ ok: false, error: 'invalid_tab_url', url }); }
      // prefer port if registered
      const portForTab = __ai_voice_ports.get(tab.id);
      if (portForTab) {
        try {
          const id = 'm' + Date.now() + '_' + Math.random().toString(36).slice(2);
          const onMsg = (m) => {
            if (m && m.id === id) {
              try { portForTab.onMessage.removeListener(onMsg); } catch (e) {}
              // clear any in-progress timer for this tab
              try { const tid = __ai_voice_inprogress_timers.get(tab.id); if (tid) { clearTimeout(tid); __ai_voice_inprogress_timers.delete(tab.id); } __ai_voice_inprogress.delete(tab.id); chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: false }); } catch (e) {}
              sendResponse(m.resp || { ok: true, result: m.resp });
            }
          };
          portForTab.onMessage.addListener(onMsg);
          portForTab.postMessage(Object.assign({ id }, message));
        } catch (e) { console.warn('port send error', e); }
        return; // async
      }
      // fallback to sendMessage with retry/inject
      const backoff = [120,300,700,1500]; let injectedOnce = false;
      const trySendWithRetryLocal = (attempt) => {
        chrome.tabs.sendMessage(tab.id, message, (resp) => {
          if (chrome.runtime.lastError) {
            const msg = chrome.runtime.lastError.message || '';
            console.warn('sendMessage error (attempt ' + attempt + '):', msg);
            if (!injectedOnce && msg.includes('Receiving end does not exist')) {
              injectedOnce = true;
              chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }, () => {
                if (chrome.runtime.lastError) { sendResponse({ ok: false, error: chrome.runtime.lastError.message || 'exec_failed' }); return; }
                setTimeout(() => { chrome.tabs.sendMessage(tab.id, { type: 'PING' }, (pong) => { if (!chrome.runtime.lastError && pong && pong.ok) { trySendWithRetryLocal(0); return; } const nextDelay = backoff[Math.min(attempt, backoff.length-1)]; setTimeout(() => trySendWithRetryLocal(attempt+1), nextDelay); }); }, 80);
              });
              return;
            }
            if (attempt < backoff.length) { const delay = backoff[attempt]; setTimeout(() => trySendWithRetryLocal(attempt+1), delay); return; }
            sendResponse({ ok: false, error: msg }); return;
          }
          sendResponse(resp || { ok: false, error: 'no-response' });
        });
      };
      trySendWithRetryLocal(0);
    });
    return true;
  }
  const getActiveTab = (cb) => {
    // Prefer the last-focused window so we pick the tab the user is looking at
    chrome.windows.getLastFocused({ populate: true }, (win) => {
      if (chrome.runtime.lastError || !win || !win.focused) {
        // If the lastFocused window is not actually focused (for example when
        // the devtools/service-worker console is open), enumerate windows and
        // choose a sensible normal window with tabs.
        chrome.windows.getAll({ populate: true }, (wins) => {
          if (chrome.runtime.lastError || !wins || !wins.length) {
            // final fallback to simple query
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => cb(tabs && tabs[0]));
            return;
          }
          // Prefer a focused normal window, otherwise prefer any normal window with tabs
          let chosen = wins.find(w => w.focused && w.type === 'normal');
          if (!chosen) chosen = wins.find(w => w.type === 'normal' && w.tabs && w.tabs.length);
          if (!chosen) chosen = wins[0];
          const tabs = chosen.tabs || [];
          const active = tabs.find(t => t.active) || tabs[0] || null;
          cb(active);
        });
        return;
      }
      const tabs = win.tabs || [];
      const active = tabs.find(t => t.active) || tabs[0] || null;
      cb(active);
    });
  };

  getActiveTab((tab) => {
    if (!tab) return sendResponse({ok: false, error: 'no-active-tab'});
    // avoid pages where extensions cannot inject content scripts — allow only http/https
    const url = tab.url || '';
    try {
      const proto = new URL(url).protocol;
      if (proto !== 'http:' && proto !== 'https:') {
        sendResponse({ ok: false, error: 'unsupported_tab_url', url });
        return;
      }
    } catch (e) {
      sendResponse({ ok: false, error: 'invalid_tab_url', url });
      return;
    }
    // forward supported types directly to content script
    const forwardTypes = ['READ_SELECTION','READ_PAGE','GET_PAGE_TEXT','PROPOSE_ACTION','PERFORM_ACTION','START_RECOGNITION','STOP_RECOGNITION','STOP_SPEECH'];
    if (forwardTypes.includes(message.type)) {
      // if the content script has an open port for this tab, prefer it
      const portForTab = __ai_voice_ports.get(tab.id);
      if (portForTab) {
        try {
          const id = 'm' + Date.now() + '_' + Math.random().toString(36).slice(2);
          const onMsg = (m) => {
            if (m && m.id === id) {
              try { portForTab.onMessage.removeListener(onMsg); } catch (e) {}
              sendResponse(m.resp || { ok: true, result: m.resp });
            }
          };
          portForTab.onMessage.addListener(onMsg);
          portForTab.postMessage(Object.assign({ id }, message));
        } catch (e) {
          console.warn('port send error', e);
        }
        return; // async response will be handled via port
      }
      // Attempt to send a message to the content script. If no receiver exists,
      // inject the content script once and retry several times with backoff.
      const backoff = [120, 300, 700, 1500];
      let injectedOnce = false;

      const trySendWithRetry = (attempt) => {
        chrome.tabs.sendMessage(tab.id, message, (resp) => {
          if (chrome.runtime.lastError) {
            const msg = chrome.runtime.lastError.message || '';
            console.warn('sendMessage error (attempt ' + attempt + '):', msg);
            // If no receiver, try injecting once then retry with backoff
            if (!injectedOnce && msg.includes('Receiving end does not exist')) {
              injectedOnce = true;
              chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] }, () => {
                if (chrome.runtime.lastError) {
                  const execMsg = chrome.runtime.lastError.message || String(chrome.runtime.lastError);
                  console.error('executeScript error:', execMsg);
                  // clear any in-progress timer
                  try { const tid = __ai_voice_inprogress_timers.get(tab.id); if (tid) { clearTimeout(tid); __ai_voice_inprogress_timers.delete(tab.id); } __ai_voice_inprogress.delete(tab.id); chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: false }); } catch (e) {}
                  sendResponse({ ok: false, error: execMsg });
                  return;
                }
                // After injecting, try pinging the content script to verify readiness
                setTimeout(() => {
                  chrome.tabs.sendMessage(tab.id, { type: 'PING' }, (pongResp) => {
                    if (!chrome.runtime.lastError && pongResp && pongResp.ok) {
                      // content script is ready — retry original send immediately
                      trySendWithRetry(0);
                      return;
                    }
                    // if ping didn't succeed, fall back to backoff retries
                    const nextDelay = backoff[Math.min(attempt, backoff.length - 1)];
                    setTimeout(() => trySendWithRetry(attempt + 1), nextDelay);
                  });
                }, 80);
              });
              return;
            }
            // if we've more attempts left, schedule another try
            if (attempt < backoff.length) {
              const delay = backoff[attempt];
              setTimeout(() => trySendWithRetry(attempt + 1), delay);
              return;
            }
            // As a last-resort fallback for page-reading requests, use executeScript
            // to collect the page text/fields directly and return them to the caller.
            if (['GET_PAGE_TEXT','READ_PAGE','READ_SELECTION'].includes(message.type)) {
              try {
                chrome.scripting.executeScript({
                  target: { tabId: tab.id },
                  func: () => {
                    const getPageArticleText = () => {
                      let el = document.querySelector('article') || document.querySelector('main');
                      if (!el) {
                        const paras = Array.from(document.querySelectorAll('p'));
                        const visible = paras.filter(p => p.offsetParent !== null);
                        return visible.map(p => p.innerText.trim()).filter(Boolean).slice(0, 200).join('\n\n');
                      }
                      return el.innerText.trim().slice(0, 20000);
                    };
                    const extractFormFields = () => {
                      const els = Array.from(document.querySelectorAll('input, textarea, select'));
                      const visible = els.filter(e => e.offsetParent !== null && e.type !== 'hidden');
                      return visible.slice(0, 200).map((el, i) => {
                        const tag = el.tagName.toLowerCase();
                        const type = el.type || tag;
                        const id = el.id || null;
                        const name = el.name || null;
                        const placeholder = el.placeholder || el.getAttribute('aria-label') || '';
                        let label = '';
                        if (id) {
                          const lab = document.querySelector(`label[for="${id}"]`);
                          if (lab) label = lab.innerText.trim();
                        }
                        if (!label) {
                          const clos = el.closest('label');
                          if (clos) label = clos.innerText.trim();
                        }
                        let selector = '';
                        if (id) selector = `#${id}`;
                        else if (name) selector = `${tag}[name="${name}"]`;
                        else if (placeholder) selector = `${tag}[placeholder]`;
                        else selector = `${tag}:nth-of-type(${i + 1})`;
                        return { label: label || '', selector, name, id, type, placeholder };
                      });
                    };
                    return { text: getPageArticleText(), fields: extractFormFields() };
                  }
                }, (results) => {
                  if (chrome.runtime.lastError) {
                    // clear any in-progress timer
                    try { const tid = __ai_voice_inprogress_timers.get(tab.id); if (tid) { clearTimeout(tid); __ai_voice_inprogress_timers.delete(tab.id); } __ai_voice_inprogress.delete(tab.id); chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: false }); } catch (e) {}
                    sendResponse({ ok: false, error: chrome.runtime.lastError.message || 'executeScript_failed' });
                    return;
                  }
                  const out = (results && results[0] && results[0].result) || null;
                  if (!out) sendResponse({ ok: false, error: 'no-result' });
                  else sendResponse({ ok: true, text: out });
                });
              } catch (e) {
                // clear any in-progress timer
                try { const tid = __ai_voice_inprogress_timers.get(tab.id); if (tid) { clearTimeout(tid); __ai_voice_inprogress_timers.delete(tab.id); } __ai_voice_inprogress.delete(tab.id); chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: false }); } catch (e2) {}
                sendResponse({ ok: false, error: String(e) });
              }
              return;
            }
            // clear any in-progress timer on final failure
            try { const tid = __ai_voice_inprogress_timers.get(tab.id); if (tid) { clearTimeout(tid); __ai_voice_inprogress_timers.delete(tab.id); } __ai_voice_inprogress.delete(tab.id); chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: false }); } catch (e) {}
            sendResponse({ ok: false, error: msg });
            return;
          }
          // clear in-progress timer when we got a response
          try { const tid = __ai_voice_inprogress_timers.get(tab.id); if (tid) { clearTimeout(tid); __ai_voice_inprogress_timers.delete(tab.id); } __ai_voice_inprogress.delete(tab.id); chrome.runtime.sendMessage({ type: 'ACTION_STATUS', tabId: tab.id, inProgress: false }); } catch (e) {}
          sendResponse(resp || { ok: false, error: 'no-response' });
        });
      };

      trySendWithRetry(0);
      return; // response will be sent asynchronously
    }
    // capture screenshot of active window/tab (dataUrl)
    if (message.type === 'CAPTURE_SCREENSHOT') {
      chrome.windows.getLastFocused({ populate: true }, (win) => {
        const winId = (win && win.id) || null;
        chrome.tabs.captureVisibleTab(winId, { format: 'png' }, (dataUrl) => {
          if (chrome.runtime.lastError) return sendResponse({ ok: false, error: chrome.runtime.lastError.message });
          sendResponse({ ok: true, dataUrl });
        });
      });
      return true;
    }
    sendResponse({ok: false, error: 'unsupported'});
  });
  // indicate we'll respond asynchronously
  return true;
});

// Keep in-page UI present when user pins it
chrome.storage.local.get(['inpagePinned'], (res) => {
  if (res && res.inpagePinned) ensurePanelOnActiveTab();
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.inpagePinned) {
    const pinned = changes.inpagePinned.newValue;
    if (pinned) ensurePanelOnActiveTab();
  }
});

chrome.tabs.onActivated.addListener(() => {
  chrome.storage.local.get(['inpagePinned'], (r) => { if (r && r.inpagePinned) ensurePanelOnActiveTab(); });
});

chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status === 'complete') chrome.storage.local.get(['inpagePinned'], (r) => { if (r && r.inpagePinned) ensurePanelOnActiveTab(); });
});

function ensurePanelOnActiveTab() {
  chrome.windows.getLastFocused({ populate: true }, (win) => {
    if (chrome.runtime.lastError || !win) {
      chrome.windows.getAll({ populate: true }, (wins) => {
        const chosen = (wins || []).find(w => w.focused && w.type === 'normal') || (wins && wins[0]);
        const tab = chosen && chosen.tabs && chosen.tabs.find(t => t.active) || (chosen && chosen.tabs && chosen.tabs[0]);
        if (tab) {
          chrome.tabs.sendMessage(tab.id, { type: 'OPEN_INPAGE_UI' }, () => {});
        }
      });
      return;
    }
    const tab = (win.tabs || []).find(t => t.active) || (win.tabs && win.tabs[0]);
    if (tab) chrome.tabs.sendMessage(tab.id, { type: 'OPEN_INPAGE_UI' }, () => {});
  });
}
