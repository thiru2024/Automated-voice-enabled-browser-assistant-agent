const startBtn = document.getElementById('startBtn');
const readBtn = document.getElementById('readBtn');
const statusEl = document.getElementById('status');
const resultEl = document.getElementById('result');
const readSelBtn = document.getElementById('readSel');
const readPageBtn = document.getElementById('readPage');
const summarizeBtn = document.getElementById('summarize');
const suggestActionBtn = document.getElementById('suggestAction');
const stopReadBtn = document.getElementById('stopRead');
const performActionBtn = document.getElementById('performActionBtn');
const cancelActionBtn = document.getElementById('cancelActionBtn');
const analyzeActionsBtn = document.getElementById('analyzeActions');

let recognizing = false;
let lastReply = '';
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let usingPageRecognizer = false;

// helper: set busy state (disable buttons and dim)
function setBusy(b) {
  const controls = [startBtn, readBtn, readSelBtn, readPageBtn, summarizeBtn, suggestActionBtn, stopReadBtn];
  for (const c of controls) if (c) c.disabled = !!b;
  if (resultEl) resultEl.style.opacity = b ? '0.6' : '1';
  if (statusEl) statusEl.style.opacity = b ? '0.8' : '1';
}

// query background for current action status on open
chrome.runtime.sendMessage({ type: 'GET_ACTION_STATUS' }, (resp) => { if (resp && resp.inProgress) setBusy(true); });

// listen to action status broadcasts from background
chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'ACTION_STATUS') {
    const inProg = !!message.inProgress;
    setBusy(inProg);
  }
});

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.continuous = true;

  recognition.addEventListener('result', async (ev) => {
    const transcript = ev.results[ev.results.length - 1][0].transcript.trim();
    statusEl.textContent = 'Heard: ' + transcript;

    // If user said 'stop' or 'stop listening' as a standalone command, stop listening.
    const tLow = transcript.toLowerCase();
    if (tLow === 'stop' || tLow === 'stop listening') {
      if (recognizing) {
        recognition.stop();
        recognizing = false;
        startBtn.textContent = 'Start Listening';
        statusEl.textContent = 'Stopped by voice command';
      }
      return;
    }

    // send recognized speech to backend
    statusEl.textContent = 'Sending to assistant...';
    try {
      const resp = await fetch('http://localhost:3001/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: transcript })
      });
      const data = await resp.json();
      resultEl.textContent = data && data.text ? data.text : JSON.stringify(data, null, 2);

      // store normalized reply for later TTS; do NOT auto-speak.
      let reply = '';
      if (data && data.text) reply = data.text;
      else if (typeof data === 'string') reply = data;
      else {
        // try to find a string field
        const findString = (obj) => {
          if (!obj) return null;
          if (typeof obj === 'string') return obj;
          if (Array.isArray(obj)) return obj.map(findString).filter(Boolean)[0] || null;
          if (typeof obj === 'object') {
            for (const k of Object.keys(obj)) {
              const v = findString(obj[k]); if (v) return v;
            }
          }
          return null;
        };
        reply = findString(data) || '';
      }

      lastReply = reply;
      readBtn.disabled = !lastReply;
      statusEl.textContent = 'Ready';
    } catch (err) {
      console.error(err);
      statusEl.textContent = 'Request failed';
    }
  });

  recognition.addEventListener('end', () => {
    recognizing = false;
    startBtn.textContent = 'Start Listening';
    if (statusEl.textContent === 'Listening...' || statusEl.textContent.startsWith('Heard:')) {
      statusEl.textContent = 'Ready';
    }
  });
} else {
  statusEl.textContent = 'SpeechRecognition not supported in this browser';
}

// Listen for recognition results forwarded from content script (page recognizer)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'RECOGNITION_RESULT') {
    const transcript = message.transcript || '';
    statusEl.textContent = 'Heard: ' + transcript;
    // send to backend same as native recognition handler
    (async () => {
      statusEl.textContent = 'Sending to assistant...';
      try {
        const resp = await fetch('http://localhost:3001/ask', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: transcript })
        });
        const data = await resp.json();
        resultEl.textContent = data && data.text ? data.text : JSON.stringify(data, null, 2);
        let reply = '';
        if (data && data.text) reply = data.text;
        else if (typeof data === 'string') reply = data;
        else {
          const findString = (obj) => {
            if (!obj) return null;
            if (typeof obj === 'string') return obj;
            if (Array.isArray(obj)) return obj.map(findString).filter(Boolean)[0] || null;
            if (typeof obj === 'object') { for (const k of Object.keys(obj)) { const v = findString(obj[k]); if (v) return v; } }
            return null;
          };
          reply = findString(data) || '';
        }
        lastReply = reply; readBtn.disabled = !lastReply; statusEl.textContent = 'Ready';
      } catch (err) { console.error(err); statusEl.textContent = 'Request failed'; }
    })();
    return sendResponse({ok:true});
  }
  if (message && message.type === 'RECOGNITION_END') {
    recognizing = false; usingPageRecognizer = false; startBtn.textContent = 'Start Listening'; statusEl.textContent = 'Ready';
    return sendResponse({ok:true});
  }
});

startBtn.addEventListener('click', () => {
  if (!recognition) return;
  if (!recognizing && !usingPageRecognizer) {
    // try to start local recognition in popup; if unsupported, request page recognizer
    if (SpeechRecognition) {
      recognition.start(); recognizing = true; startBtn.textContent = 'Stop Listening'; statusEl.textContent = 'Listening...';
    } else {
      // ask content script to start recognition in page context
      chrome.runtime.sendMessage({ type: 'START_RECOGNITION' }, (resp) => {
        if (resp && resp.ok) { usingPageRecognizer = true; recognizing = true; startBtn.textContent = 'Stop Listening'; statusEl.textContent = 'Listening on page...'; }
        else statusEl.textContent = 'Start failed';
      });
    }
  } else {
    // stop whichever recognizer is active
    if (usingPageRecognizer) {
      chrome.runtime.sendMessage({ type: 'STOP_RECOGNITION' }, (resp) => {
        usingPageRecognizer = false; recognizing = false; startBtn.textContent = 'Start Listening'; statusEl.textContent = 'Stopping...';
      });
    } else if (recognition) {
      recognition.stop(); recognizing = false; startBtn.textContent = 'Start Listening'; statusEl.textContent = 'Stopping...';
    }
  }
});

// Keep the extension window open in a persistent popup
const pinBtn = document.getElementById('pinWindow');
if (pinBtn) {
  // initialize button state from storage
  chrome.storage.local.get(['inpagePinned'], (r) => {
    const pinned = !!(r && r.inpagePinned);
    pinBtn.textContent = pinned ? 'Unpin' : 'Keep Open';
  });
  pinBtn.addEventListener('click', () => {
    chrome.storage.local.get(['inpagePinned'], (r) => {
      const pinned = !!(r && r.inpagePinned);
      const next = !pinned;
      chrome.storage.local.set({ inpagePinned: next }, () => {
        pinBtn.textContent = next ? 'Unpin' : 'Keep Open';
        if (next) {
          // request background to open panel on current active tab
          chrome.runtime.sendMessage({ type: 'OPEN_INPAGE_UI' });
        } else {
          // request panel close on current active tab
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'CLOSE_INPAGE_UI' }, () => {});
          });
        }
        try { window.close(); } catch (e) {}
      });
    });
  });
}

readBtn.addEventListener('click', () => {
  if (!lastReply) return;
  try {
    const ut = new SpeechSynthesisUtterance(lastReply);
    ut.rate = 1.15;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(ut);
  } catch (e) {
    console.warn('TTS failed', e);
  }
});

readSelBtn.addEventListener('click', () => {
  // ask active tab to read selection (or main article)
  setBusy(true);
  chrome.runtime.sendMessage({ type: 'START_ACTION' }, () => {
    chrome.runtime.sendMessage({ type: 'READ_SELECTION' }, (resp) => {
      if (resp && resp.ok) statusEl.textContent = 'Reading selection/page'; else statusEl.textContent = 'Nothing to read';
      chrome.runtime.sendMessage({ type: 'END_ACTION' });
      setBusy(false);
    });
  });
});

readPageBtn.addEventListener('click', () => {
  setBusy(true);
  chrome.runtime.sendMessage({ type: 'START_ACTION' }, () => {
    chrome.runtime.sendMessage({ type: 'READ_PAGE' }, (resp) => {
      if (resp && resp.ok) statusEl.textContent = 'Reading page'; else statusEl.textContent = 'Read failed';
      chrome.runtime.sendMessage({ type: 'END_ACTION' });
      setBusy(false);
    });
  });
});

stopReadBtn.addEventListener('click', () => {
  // Cancel any speech in popup and request page speech cancellation
  try { window.speechSynthesis.cancel(); } catch (e) {}
  setBusy(true);
  chrome.runtime.sendMessage({ type: 'START_ACTION' }, () => {
    chrome.runtime.sendMessage({ type: 'STOP_SPEECH' }, (resp) => {
      if (resp && resp.ok) statusEl.textContent = 'Stopped reading'; else statusEl.textContent = 'Stop request sent';
      chrome.runtime.sendMessage({ type: 'END_ACTION' });
      setBusy(false);
    });
  });
});

summarizeBtn.addEventListener('click', async () => {
  statusEl.textContent = 'Getting page text...';
  setBusy(true);
  chrome.runtime.sendMessage({ type: 'START_ACTION' }, () => {
    chrome.runtime.sendMessage({ type: 'GET_PAGE_TEXT' }, async (resp) => {
      if (!resp || !resp.ok) { statusEl.textContent = 'Unable to read page'; setBusy(false); chrome.runtime.sendMessage({ type: 'END_ACTION' }); return; }
      const pageObj = resp.text || {};
      const pageText = typeof pageObj === 'string' ? pageObj : (pageObj.text || '');
      const fields = (pageObj && pageObj.fields) ? pageObj.fields : [];
      statusEl.textContent = 'Asking assistant for structured summary...';
      try {
        const prompt = `You are an assistant. Summarize the MAIN POINTS of the page content in 3-6 short bullets. Then list detected form fields on the page as an array with each item containing: label, selector, name, type, placeholder. Return ONLY valid JSON in this exact shape: {"summary": ["...","..."], "fields": [{"label":"","selector":"","name":"","type":"","placeholder":""}]}. Page content:\n\n${pageText}\n\nDetected fields (best-effort):\n${JSON.stringify(fields, null, 2)}`;
        const r = await fetch('http://localhost:3001/ask', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ prompt }) });
        const data = await r.json();
        const text = data && data.text ? data.text : (typeof data === 'string' ? data : JSON.stringify(data));
        // parse JSON from assistant
        let parsed = null;
        try { parsed = JSON.parse(text); } catch (e) {
          const js = text.match(/\{[\s\S]*\}/m);
          if (js) try { parsed = JSON.parse(js[0]); } catch (e) { parsed = null; }
        }
        if (!parsed) {
          // attempt to ask the assistant to extract/return only the JSON object
          try {
            const extractPrompt = `The assistant returned the following text. Extract and return ONLY the JSON object contained within it, with no extra commentary:\n\n${text}`;
            const xr = await fetch('http://localhost:3001/ask', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ prompt: extractPrompt }) });
            const xdata = await xr.json();
            const xtext = xdata && xdata.text ? xdata.text : (typeof xdata === 'string' ? xdata : JSON.stringify(xdata));
            const js = xtext.match(/\{[\s\S]*\}/m);
            if (js) {
              try { parsed = JSON.parse(js[0]); } catch (e) { parsed = null; }
            }
          } catch (e) { parsed = null; }
        }
        if (!parsed) {
          resultEl.textContent = 'Assistant did not return valid JSON. Raw response:\n' + text;
          statusEl.textContent = 'No structured summary';
          setBusy(false);
          chrome.runtime.sendMessage({ type: 'END_ACTION' });
          return;
        }
        // display nicely
        const bullets = (parsed.summary && Array.isArray(parsed.summary)) ? parsed.summary : [];
        const out = [];
        out.push('Summary:\n' + bullets.map(b => '- ' + b).join('\n'));
        out.push('\nFields:\n' + (parsed.fields && parsed.fields.length ? parsed.fields.map(f => `- ${f.label || f.name || ''} (${f.selector || f.name || f.type || ''})`).join('\n') : 'No fields found'));
        resultEl.textContent = out.join('\n\n');
        lastReply = bullets.join(' ');
        readBtn.disabled = !lastReply;
        statusEl.textContent = 'Structured summary ready';
      } catch (e) {
        console.error(e); statusEl.textContent = 'Summary failed';
      }
      setBusy(false);
      chrome.runtime.sendMessage({ type: 'END_ACTION' });
    });
  });
});

suggestActionBtn.addEventListener('click', async () => {
  statusEl.textContent = 'Analyzing page for suggested actions...';
  chrome.runtime.sendMessage({ type: 'GET_PAGE_TEXT' }, async (resp) => {
    if (!resp || !resp.ok) { statusEl.textContent = 'Unable to read page'; return; }
    const pageText = resp.text || '';
    try {
      // If page content is very small, treat it as incomplete and avoid asking the assistant
      const plainText = (typeof pageText === 'string') ? pageText : (pageText && pageText.text) ? pageText.text : '';
      if (!plainText || plainText.trim().length < 200) {
        statusEl.textContent = 'Page content appears incomplete — no safe actions available';
        resultEl.textContent = 'The page appears to have insufficient or restricted content for reliable action suggestions.';
        return;
      }

      const prompt = `Analyze the following page and suggest one safe DOM action the assistant could perform (json output). Provide a JSON object with keys: message (user-facing suggestion) and action (object with type: 'click'|'fill'|'navigate', selector (if applicable), value (if fill)). Page content:\n\n${plainText}`;
      const r = await fetch('http://localhost:3001/ask', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ prompt }) });
      const data = await r.json();
      // try to parse JSON in response text
      let parsed = null;
      const text = data && data.text ? data.text : (typeof data === 'string' ? data : JSON.stringify(data));
      try { parsed = JSON.parse(text); } catch (e) {
        // try to extract JSON substring
        const js = text.match(/\{[\s\S]*\}/m);
        if (js) try { parsed = JSON.parse(js[0]); } catch (e) { parsed = null; }
      }
      // If assistant returned an obvious error or warning instead of a suggestion, show friendly message
      if (!parsed) {
        const lower = (text || '').toLowerCase();
        if (lower.includes('provided page content appears') || lower.includes('incomplete') || lower.includes('error or incomplete')) {
          resultEl.textContent = text;
          statusEl.textContent = 'No suggestion — page content incomplete';
          return;
        }
      }
      if (!parsed) {
        resultEl.textContent = 'No structured suggestion returned: ' + text;
        statusEl.textContent = 'No suggestion';
        return;
      }
      // show suggestion in popup and allow explicit Perform/Cancel
      resultEl.textContent = JSON.stringify(parsed, null, 2);
      statusEl.textContent = 'Proposal ready — review and Perform to execute';
      if (performActionBtn && cancelActionBtn) {
        performActionBtn.style.display = 'inline-block';
        cancelActionBtn.style.display = 'inline-block';
      }
      // store suggestion for later perform
      window.__ai_voice_pendingSuggestion = parsed;
    } catch (e) { console.error(e); statusEl.textContent = 'Suggestion failed'; }
  });
});

// Analyze Actions: collect actionable items + screenshot and show preview
if (analyzeActionsBtn) {
  analyzeActionsBtn.addEventListener('click', async () => {
    statusEl.textContent = 'Collecting actionable items and screenshot...';
    setBusy(true);
    chrome.runtime.sendMessage({ type: 'START_ACTION' }, async () => {
      try {
        // get active tab id
        const tabs = await new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, r));
        const tabId = (tabs && tabs[0] && tabs[0].id) || null;
        if (!tabId) { statusEl.textContent = 'No active tab'; setBusy(false); chrome.runtime.sendMessage({ type: 'END_ACTION' }); return; }

        // ask content script directly for actionable items
        const items = await new Promise((resolve) => {
          try {
            chrome.tabs.sendMessage(tabId, { type: 'GET_ACTIONABLE_ITEMS' }, (resp) => { resolve(resp); });
          } catch (e) { resolve(null); }
        });

        // request screenshot from background
        const shot = await new Promise((resolve) => {
          try { chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT' }, (r) => resolve(r)); } catch (e) { resolve(null); }
        });

        const itemsList = (items && items.ok && Array.isArray(items.items)) ? items.items : (items && items.items) ? items.items : null;
        const out = { items: itemsList || [], screenshot: (shot && shot.dataURL) ? '[dataURL]' : (shot && shot.ok ? 'screenshot-ok' : 'no-screenshot') };
        resultEl.textContent = JSON.stringify(out, null, 2);
        statusEl.textContent = 'Collected actionable items — review below';
      } catch (e) {
        console.error(e); statusEl.textContent = 'Analyze failed';
      }
      setBusy(false);
      chrome.runtime.sendMessage({ type: 'END_ACTION' });
    });
  });
}

// Perform / Cancel handlers for suggested actions shown in popup
if (performActionBtn) {
  performActionBtn.addEventListener('click', () => {
    const parsed = window.__ai_voice_pendingSuggestion;
    if (!parsed) { statusEl.textContent = 'No pending suggestion'; return; }
    setBusy(true);
    chrome.runtime.sendMessage({ type: 'START_ACTION' }, () => {
      // determine the active page tab to target the action (popup may be focused)
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tabId = (tabs && tabs[0] && tabs[0].id) || null;
        chrome.runtime.sendMessage({ type: 'PROPOSE_ACTION', payload: parsed, tabId }, (res) => {
        if (res && res.ok) statusEl.textContent = 'Action performed';
        else if (res && res.cancelled) statusEl.textContent = 'Action cancelled by user';
        else statusEl.textContent = 'Action failed or no response';
        // clear UI
        if (performActionBtn && cancelActionBtn) {
          performActionBtn.style.display = 'none';
          cancelActionBtn.style.display = 'none';
        }
        window.__ai_voice_pendingSuggestion = null;
        chrome.runtime.sendMessage({ type: 'END_ACTION' });
        setBusy(false);
        });
      });
    });
  });
}
if (cancelActionBtn) {
  cancelActionBtn.addEventListener('click', () => {
    window.__ai_voice_pendingSuggestion = null;
    if (performActionBtn && cancelActionBtn) {
      performActionBtn.style.display = 'none';
      cancelActionBtn.style.display = 'none';
    }
    statusEl.textContent = 'Suggestion cancelled';
  });
}
