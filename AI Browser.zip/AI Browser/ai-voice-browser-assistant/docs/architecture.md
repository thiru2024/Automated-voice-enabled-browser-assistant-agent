# Architecture notes

This document will hold high-level design notes for the AI Voice Browser Assistant.

- Voice -> STT -> command parsing -> Browser actions
- Consider local TTS / STT or cloud providers
- Browser automation via puppeteer or extension APIs
