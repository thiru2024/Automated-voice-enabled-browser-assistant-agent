const assert = require('assert');

describe('basic', ()=>{
  it('sanity', ()=>{
    assert.strictEqual(1+1,2);
  });
});
