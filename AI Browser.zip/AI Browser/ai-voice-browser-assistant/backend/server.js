require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
// Serve a small static test page from / (backend/public)
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3001;

app.get('/health', (req, res) => res.json({status: 'ok'}));

// Debug route (no secrets) — reports whether Ollama env var is present
app.get('/debug-env', (req, res) => {
  res.json({
    OLLAMA_MODEL_set: !!process.env.OLLAMA_MODEL,
    PORT: process.env.PORT || PORT
  });
});

app.post('/command', (req, res) => {
  console.log('Received command:', req.body);
  // TODO: validate and forward to assistant/LLM
  res.json({received: true});
});

app.post('/ask', async (req, res) => {
  try {
    const { prompt, messages } = req.body || {};
    const ollamaUrl = 'http://127.0.0.1:11434';
    const ollamaModel = process.env.OLLAMA_MODEL;
    if (!ollamaModel) return res.status(500).json({ error: 'OLLAMA_MODEL not set in environment' });
    const endpoint = `${ollamaUrl}/api/generate`;

    const promptText = messages ? messages.map(m => `${m.role}: ${m.content}`).join('\n') : (prompt || '');
    const body = { model: ollamaModel, prompt: promptText };

    console.log('Calling Ollama:', { endpoint, model: ollamaModel });
    console.log('Prompt length:', String(promptText).length);

    let resp;
    try {
      resp = await axios.post(endpoint, body, {
        headers: { 'Content-Type': 'application/json' },
        timeout: 20000
      });
      console.log('Ollama responded status:', resp.status);
      console.log('Ollama raw response keys:', Object.keys(resp.data || {}));
    } catch (e) {
      // If Ollama says the model was not found and the model contains a ".1" variant,
      // try a fallback by removing the ".1" segment (e.g. qwen3.1:8B -> qwen3:8B).
      const msg = e.response && e.response.data && (e.response.data.error || JSON.stringify(e.response.data));
      console.error('Initial Ollama call failed:', msg || e.message);
      if (msg && ollamaModel.includes('.1') && /model .* not found/i.test(String(msg))) {
        const altModel = ollamaModel.replace('.1', '');
        console.log(`Retrying with alternate model '${altModel}'`);
        body.model = altModel;
        try {
          resp = await axios.post(endpoint, body, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 20000
          });
          console.log('Ollama responded on retry status:', resp.status);
          console.log('Ollama raw response keys (retry):', Object.keys(resp.data || {}));
        } catch (e2) {
          console.error('Retry also failed:', e2.response ? e2.response.data : e2.message);
          throw e2;
        }
      } else {
        throw e;
      }
    }

    const data = resp.data;
    let text = null;

    // Existing structured response (array of results)
    if (data && data.results) {
      for (const r of data.results) {
        if (r && r.content) {
          for (const c of r.content) {
            if (c && typeof c === 'object') {
              if (c.text) { text = c.text; break; }
              if (c.type === 'output_text' && c.text) { text = c.text; break; }
            } else if (typeof c === 'string') {
              text = c; break;
            }
          }
          if (text) break;
        }
      }
    } else {
      // Handle NDJSON or newline-delimited JSON strings from Ollama
      const rawString = typeof data === 'string' ? data : (data && data.raw && typeof data.raw === 'string' ? data.raw : null);
      if (rawString) {
        const lines = rawString.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
        const parts = [];
        for (const line of lines) {
          try {
            const obj = JSON.parse(line);
            if (obj.response && String(obj.response).length) parts.push(String(obj.response));
          } catch (e) {
            // ignore parse errors for any non-json line
          }
        }
        if (parts.length) text = parts.join('');
      }
    }

    return res.json({ raw: data, text });
  } catch (err) {
    console.error('LLM request error: ', err.message);
    if (err.response) {
      console.error('Ollama response error status:', err.response.status);
      console.error('Ollama response error data:', JSON.stringify(err.response.data));
    }
    return res.status(500).json({ error: 'LLM request failed', details: err.response ? err.response.data : err.message });
  }
});

// Streaming proxy: forwards Ollama NDJSON stream to the browser
app.post('/ask/stream', async (req, res) => {
  try {
    const { prompt, messages } = req.body || {};
    const ollamaUrl = 'http://127.0.0.1:11434';
    let ollamaModel = process.env.OLLAMA_MODEL;
    if (!ollamaModel) return res.status(500).json({ error: 'OLLAMA_MODEL not set in environment' });
    const endpoint = `${ollamaUrl}/api/generate`;

    const promptText = messages ? messages.map(m => `${m.role}: ${m.content}`).join('\n') : (prompt || '');
    const body = { model: ollamaModel, prompt: promptText };

    console.log('[stream] Calling Ollama stream:', { endpoint, model: ollamaModel });

    // Attempt streaming request; if model not found and contains .1, retry without .1
    let upstream;
    try {
      upstream = await axios.post(endpoint, body, { headers: { 'Content-Type': 'application/json' }, responseType: 'stream', timeout: 0 });
    } catch (e) {
      const msg = e.response && e.response.data && (e.response.data.error || JSON.stringify(e.response.data));
      console.error('[stream] initial call failed:', msg || e.message);
      if (msg && ollamaModel.includes('.1') && /model .* not found/i.test(String(msg))) {
        const altModel = ollamaModel.replace('.1', '');
        console.log(`[stream] Retrying with alternate model '${altModel}'`);
        body.model = altModel;
        upstream = await axios.post(endpoint, body, { headers: { 'Content-Type': 'application/json' }, responseType: 'stream', timeout: 0 });
      } else {
        console.error('[stream] upstream error', e.response ? e.response.data : e.message);
        return res.status(500).json({ error: 'upstream_stream_failed', details: e.response ? e.response.data : e.message });
      }
    }

    res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
    res.setHeader('Cache-Control', 'no-cache');

    // Pipe data chunks as they arrive
    upstream.data.on('data', (chunk) => {
      try { res.write(chunk); } catch (err) { console.error('[stream] write error', err); }
    });
    upstream.data.on('end', () => {
      try { res.end(); } catch (e) { /* ignore */ }
    });
    upstream.data.on('error', (err) => {
      console.error('[stream] upstream stream error', err);
      try { res.end(); } catch (e) {}
    });

  } catch (err) {
    console.error('/ask/stream error:', err.response ? err.response.data : err.message);
    return res.status(500).json({ error: 'stream request failed', details: err.response ? err.response.data : err.message });
  }
});

// Explicit route that always targets local Ollama daemon
app.post('/ask/local-ollama', async (req, res) => {
  try {
    const { prompt, messages } = req.body || {};
    const ollamaUrl = 'http://127.0.0.1:11434';
    const ollamaModel = process.env.OLLAMA_MODEL;
    if (!ollamaModel) return res.status(500).json({ error: 'OLLAMA_MODEL not set in environment' });
    const endpoint = `${ollamaUrl}/api/generate`;

    const promptText = messages ? messages.map(m => `${m.role}: ${m.content}`).join('\n') : (prompt || '');
    const body = { model: ollamaModel, prompt: promptText };

    console.log('[local-ollama] Calling Ollama:', { endpoint, model: ollamaModel });
    console.log('[local-ollama] Prompt length:', String(promptText).length);

    let resp;
    try {
      resp = await axios.post(endpoint, body, {
        headers: { 'Content-Type': 'application/json' },
        timeout: 20000
      });
      console.log('[local-ollama] Response status:', resp.status);
      console.log('[local-ollama] Raw response keys:', Object.keys(resp.data || {}));
    } catch (e) {
      const msg = e.response && e.response.data && (e.response.data.error || JSON.stringify(e.response.data));
      console.error('[local-ollama] Initial call failed:', msg || e.message);
      if (msg && ollamaModel.includes('.1') && /model .* not found/i.test(String(msg))) {
        const altModel = ollamaModel.replace('.1', '');
        console.log(`[local-ollama] Retrying with alternate model '${altModel}'`);
        body.model = altModel;
        try {
          resp = await axios.post(endpoint, body, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 20000
          });
          console.log('[local-ollama] Response status (retry):', resp.status);
          console.log('[local-ollama] Raw response keys (retry):', Object.keys(resp.data || {}));
        } catch (e2) {
          console.error('[local-ollama] Retry also failed:', e2.response ? e2.response.data : e2.message);
          throw e2;
        }
      } else {
        throw e;
      }
    }

    const data = resp.data;
    let text = null;

    if (data && data.results) {
      for (const r of data.results) {
        if (r && r.content) {
          for (const c of r.content) {
            if (c && typeof c === 'object') {
              if (c.text) { text = c.text; break; }
              if (c.type === 'output_text' && c.text) { text = c.text; break; }
            } else if (typeof c === 'string') {
              text = c; break;
            }
          }
          if (text) break;
        }
      }
    } else {
      const rawString = typeof data === 'string' ? data : (data && data.raw && typeof data.raw === 'string' ? data.raw : null);
      if (rawString) {
        const lines = rawString.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
        const parts = [];
        for (const line of lines) {
          try {
            const obj = JSON.parse(line);
            if (obj.response && String(obj.response).length) parts.push(String(obj.response));
          } catch (e) {}
        }
        if (parts.length) text = parts.join('');
      }
    }

    return res.json({ raw: data, text });
  } catch (err) {
    console.error('/ask/local-ollama error:', err.response ? err.response.data : err.message);
    return res.status(500).json({ error: 'local-ollama request failed', details: err.response ? err.response.data : err.message });
  }
});

app.listen(PORT, async () => {
  console.log(`Backend listening on port ${PORT}`);
  // lightweight pre-warm: ask Ollama a trivial prompt to load model into memory
  try {
    const ollamaUrl = 'http://127.0.0.1:11434';
    const endpoint = `${ollamaUrl}/api/generate`;
    const ollamaModel = process.env.OLLAMA_MODEL;
    if (ollamaModel) {
      console.log('Pre-warming model', ollamaModel);
      axios.post(endpoint, { model: ollamaModel, prompt: 'Hello' }, { headers: { 'Content-Type': 'application/json' }, timeout: 30000 })
        .then(r => console.log('Pre-warm response status:', r.status))
        .catch(e => console.warn('Pre-warm failed:', e.response ? e.response.data : e.message));
    }
  } catch (e) {
    console.warn('Pre-warm unexpected error', e.message);
  }
});
