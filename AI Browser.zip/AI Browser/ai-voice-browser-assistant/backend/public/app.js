// Voice-first test page script
const startBtn = document.getElementById('startListen');
const readBtn = document.getElementById('readBtn');
const textOutput = document.getElementById('textOutput');
const resultEl = document.getElementById('result');
const toggleRaw = document.getElementById('toggleRaw');
const rawContainer = document.getElementById('rawContainer');

let recognizing = false;
let lastReply = '';
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;

if (toggleRaw && rawContainer) {
  rawContainer.style.display = 'none';
  toggleRaw.checked = false;
  toggleRaw.addEventListener('change', () => {
    rawContainer.style.display = toggleRaw.checked ? 'block' : 'none';
  });
}

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  recognition.continuous = true;

  recognition.addEventListener('result', async (ev) => {
    const transcript = ev.results[ev.results.length - 1][0].transcript.trim();
    textOutput.textContent = 'Heard: ' + transcript;

    const tLow = transcript.toLowerCase();
    if (tLow === 'stop' || tLow === 'stop listening') {
      if (recognizing) {
        recognition.stop();
        recognizing = false;
        startBtn.textContent = 'Start Listening';
        textOutput.textContent = 'Stopped by voice command';
      }
      return;
    }

    textOutput.textContent = 'Sending to assistant (stream)...';
    try {
      const resp = await fetch('/ask/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: transcript })
      });
      if (!resp.ok) {
        const errText = await resp.text().catch(() => 'stream error');
        textOutput.textContent = 'Stream request failed: ' + errText;
        return;
      }

      // Stream parsing
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let wasRecognizing = recognizing;
      // pause recognition when first chunk arrives (we'll resume on done)
      let pausedForSpeech = false;
      const speechQueue = [];
      let speaking = false;
      let pendingResponse = '';
      let mergeTimer = null;
      const MERGE_WINDOW_MS = 200; // allow slightly longer aggregation for natural flow
      const MAX_MERGE_CHARS = 120; // flush when aggregated text is reasonably long
      let streamDone = false;

      const flushPending = () => {
        if (mergeTimer) { clearTimeout(mergeTimer); mergeTimer = null; }
        if (pendingResponse) {
          speechQueue.push(pendingResponse);
          pendingResponse = '';
          playQueue();
        }
      };

      const attemptResume = () => {
        // only resume if stream ended and no more speech is queued or speaking
        if (!streamDone) return;
        if (speechQueue.length === 0 && !speaking && !window.speechSynthesis.speaking) {
          if (pausedForSpeech && wasRecognizing) {
            try { recognition.start(); recognizing = true; startBtn.textContent = 'Stop Listening'; pausedForSpeech = false; streamDone = false; } catch (e) {}
          } else {
            streamDone = false;
          }
        }
      };

      const playQueue = () => {
        if (speaking || speechQueue.length === 0) return;
        speaking = true;
        const chunk = speechQueue.shift();
        console.log('TTS playQueue speaking:', chunk);
        const ut = new SpeechSynthesisUtterance(chunk);
        // keep a fast playback rate
        ut.rate = 1.6; // more natural than extreme speed
        ut.onend = () => {
          speaking = false;
          // minimal delay to chain fragments more smoothly
          setTimeout(playQueue, 20);
          // after finishing one fragment, if queue empty, try to resume recognition
          setTimeout(() => { if (speechQueue.length === 0 && !speaking) attemptResume(); }, 40);
        };
        // Do NOT cancel existing speech here; speak fragments sequentially
        window.speechSynthesis.speak(ut);
      };

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split(/\r?\n/);
        buffer = lines.pop();
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const obj = JSON.parse(line);
            // prefer `response` fragments; ignore `thinking`
            if (obj.response && String(obj.response).length) {
              // if first response fragment, pause recognition
              if (!pausedForSpeech && wasRecognizing) {
                try { recognition.stop(); } catch (e) {}
                pausedForSpeech = true;
                startBtn.textContent = 'Start Listening';
              }
              // append and queue for speech
              textOutput.textContent = (textOutput.textContent === 'Sending to assistant (stream)...' || textOutput.textContent.startsWith('Heard:')) ? obj.response : (textOutput.textContent + obj.response);
              // micro-merge short, near-simultaneous fragments to reduce TTS gaps
              pendingResponse += String(obj.response);
              // flush early if we hit punctuation or a reasonable size
              if (/[.!?]\s*$/.test(pendingResponse) || pendingResponse.length >= MAX_MERGE_CHARS) {
                flushPending();
              } else {
                if (mergeTimer) clearTimeout(mergeTimer);
                mergeTimer = setTimeout(flushPending, MERGE_WINDOW_MS);
              }
            }
            // If stream signals done, resume recognition if it was active
            if (obj.done) {
              // flush any pending merged fragments before finishing
              flushPending();
              // mark stream done; resume recognition only after speech finishes
              streamDone = true;
              lastReply = textOutput.textContent || lastReply;
              readBtn.disabled = !lastReply;
              resultEl.textContent = JSON.stringify({ raw: null, text: lastReply }, null, 2);
              attemptResume();
            }
          } catch (e) {
            // ignore parse errors
          }
        }
      }
      // leftover buffer
      if (buffer.trim()) {
        try {
          const obj = JSON.parse(buffer);
          if (obj.response) {
            if (!pausedForSpeech && wasRecognizing) {
              try { recognition.stop(); } catch (e) {}
              pausedForSpeech = true;
              startBtn.textContent = 'Start Listening';
            }
            textOutput.textContent = (textOutput.textContent === 'Sending to assistant (stream)...' || textOutput.textContent.startsWith('Heard:')) ? obj.response : (textOutput.textContent + obj.response);
            pendingResponse += String(obj.response);
            if (/[.!?]\s*$/.test(pendingResponse) || pendingResponse.length >= MAX_MERGE_CHARS) {
              flushPending();
            } else {
              if (mergeTimer) clearTimeout(mergeTimer);
              mergeTimer = setTimeout(flushPending, MERGE_WINDOW_MS);
            }
          }
          if (obj.done) {
            flushPending();
            streamDone = true;
            lastReply = textOutput.textContent || lastReply;
            readBtn.disabled = !lastReply;
            resultEl.textContent = JSON.stringify({ raw: null, text: lastReply }, null, 2);
            attemptResume();
          }
        } catch (e) {}
      }

    } catch (err) {
      textOutput.textContent = 'Stream request failed: ' + (err.message || err);
      resultEl.textContent = '';
    }
  });

  recognition.addEventListener('end', () => {
    recognizing = false;
    startBtn.textContent = 'Start Listening';
  });
} else {
  if (textOutput) textOutput.textContent = 'SpeechRecognition not supported in this browser';
}

startBtn.addEventListener('click', () => {
  if (!recognition) return;
  if (!recognizing) {
    recognition.start();
    recognizing = true;
    startBtn.textContent = 'Stop Listening';
    if (textOutput) textOutput.textContent = 'Listening...';
  } else {
    recognition.stop();
    recognizing = false;
    startBtn.textContent = 'Start Listening';
    if (textOutput) textOutput.textContent = 'Stopped';
  }
});

readBtn.addEventListener('click', () => {
  if (!lastReply) return;
  try {
    const ut = new SpeechSynthesisUtterance(lastReply);
    ut.rate = 2;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(ut);
  } catch (e) { alert('TTS failed: ' + e.message); }
});
