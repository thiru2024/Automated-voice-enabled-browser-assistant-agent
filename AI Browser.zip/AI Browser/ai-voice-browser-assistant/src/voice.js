// Minimal voice module placeholder
class Voice {
  async init(){
    console.log('Voice subsystem initialized (stub)');
  }

  async listen(){
    // implement speech-to-text integration here
    return '';
  }
}

module.exports = Voice;
