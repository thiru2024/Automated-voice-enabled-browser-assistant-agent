// Minimal browser control placeholder
class Browser {
  async init(){
    console.log('Browser subsystem initialized (stub)');
  }

  async openUrl(url){
    console.log('Opening URL (stub):', url);
  }
}

module.exports = Browser;
