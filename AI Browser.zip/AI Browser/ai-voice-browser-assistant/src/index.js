// Entry point for AI Voice Browser Assistant (starter)
const Voice = require('./voice');
const Browser = require('./browser');

async function main(){
  console.log('Starting AI Voice Browser Assistant (stub)');
  const voice = new Voice();
  const browser = new Browser();
  // placeholder: wire voice commands to browser actions
  await voice.init();
  await browser.init();
  console.log('Ready — implement features in src/voice.js and src/browser.js');
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
